﻿namespace PokemonsWebAPI.DTO;

public class PokemonDTO
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string PhotoPath { get; set; }
}