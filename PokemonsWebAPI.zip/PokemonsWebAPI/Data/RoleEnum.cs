﻿namespace PokemonsWebAPI;

public enum RoleEnum
{
    Admin = 1,
    User = 2,
    Guest = 3
}