﻿namespace PokemonsWebAPI;

public enum UserActivityEnum
{
    Entry = 1,
    Exit = 2
}